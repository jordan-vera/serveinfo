OC.L10N.register(
    "serverinfo",
    {
    "Users" : "Benotzer",
    "Groups" : "Gruppen",
    "Copied!" : "Kopéiert!",
    "Not supported!" : "Nët ennerstëtzt!",
    "Press ⌘-C to copy." : "Dréck ⌘-C fir ze kopéieren.",
    "Press Ctrl-C to copy." : "Dréck CTRL-C fir ze kopéieren.",
    "Size" : "Gréisst",
    "Type:" : "Typ:",
    "Size:" : "Gréisst:"
},
"nplurals=2; plural=(n != 1);");
