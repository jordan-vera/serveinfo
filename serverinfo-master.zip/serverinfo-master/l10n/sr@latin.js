OC.L10N.register(
    "serverinfo",
    {
    "Groups" : "Grupe",
    "24 hours" : "24 sata",
    "1 hour" : "1 sat",
    "Copy" : "Kopiraj",
    "Copied!" : "Копирано!",
    "Not supported!" : "Није подржано!",
    "Press ⌘-C to copy." : "Притисни ⌘-C за копирање.",
    "Press Ctrl-C to copy." : "Притисни Ctrl-C за копирање.",
    "Type:" : "Tip:",
    "Size:" : "Veličina:"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
