OC.L10N.register(
    "serverinfo",
    {
    "Load average" : "O'rtacha yuk",
    "Total" : "Jami",
    "Users" : "Foydalanuvchilar",
    "Groups" : "Guruhlar",
    "Copy" : "Nusxalash",
    "Copied!" : "Nusxa olindi!",
    "Not supported!" : "Qo'llab-quvvatlanmaydi!",
    "Press ⌘-C to copy." : "Ko'chirib olish uchun ⌘-C tugmasini bosing.",
    "Press Ctrl-C to copy." : "Nusxalash uchun Ctrl-C tugmalarini bosing.",
    "System" : "Tizim"
},
"nplurals=1; plural=0;");
