OC.L10N.register(
    "serverinfo",
    {
    "Users" : "Pengguna",
    "Groups" : "Kumpulan",
    "Copied!" : "Disalin!",
    "Not supported!" : "Tidak menyokong!",
    "Press ⌘-C to copy." : "Tekan ⌘-C untuk menyalin.",
    "Press Ctrl-C to copy." : "Tekan Ctrl-C untuk menyalin.",
    "Size" : "Saiz",
    "Shares" : "Kongsi",
    "Type:" : "Jenis",
    "Size:" : "Saiz"
},
"nplurals=1; plural=0;");
