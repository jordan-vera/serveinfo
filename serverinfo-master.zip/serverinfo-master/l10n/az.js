OC.L10N.register(
    "serverinfo",
    {
    "Users" : "İstifadəçilər",
    "Groups" : "Qruplar",
    "System" : "Sistem",
    "Size" : "Həcm",
    "Hostname" : "Sahibadı",
    "Shares" : "Yayımlanmalar",
    "Type:" : "Tip:",
    "Size:" : "Həcm:"
},
"nplurals=2; plural=(n != 1);");
