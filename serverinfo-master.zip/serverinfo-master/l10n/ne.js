OC.L10N.register(
    "serverinfo",
    {
    "Copied!" : "प्रतिलिपि गरियो!",
    "Not supported!" : "समर्थित छैन!",
    "Press ⌘-C to copy." : "प्रतिलिपि गर्न ⌘-C थिच्नुहोस्।",
    "Press Ctrl-C to copy." : "प्रतिलिपि गर्न Ctrl-C थिच्नुहोस्।"
},
"nplurals=2; plural=(n != 1);");
