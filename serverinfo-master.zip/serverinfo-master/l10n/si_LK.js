OC.L10N.register(
    "serverinfo",
    {
    "Users" : "පරිශීලකයන්",
    "Groups" : "කණ්ඩායම්",
    "Copied!" : "පිටපත් කරා",
    "Not supported!" : "සහාය දක්වන්නේ නැත.",
    "Press ⌘-C to copy." : "පිටපත් කිරීම සදහා Ctrl + C ඔබන්න.",
    "Press Ctrl-C to copy." : "පිටපත් කිරීම සදහා Ctrl + C ඔබන්න.",
    "Size" : "ප්‍රමාණය",
    "Type:" : "ගණය:",
    "Size:" : "විශාලත්වය:"
},
"nplurals=2; plural=(n != 1);");
