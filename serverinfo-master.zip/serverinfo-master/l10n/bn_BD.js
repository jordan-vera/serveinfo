OC.L10N.register(
    "serverinfo",
    {
    "Users" : "ব্যবহারকারী",
    "Groups" : "গোষ্ঠীসমূহ",
    "Size" : "আকার",
    "Hostname" : "হোস্টনেম",
    "Shares" : "ভাগাভাগি",
    "Type:" : "ধরণঃ",
    "Size:" : "আয়তনঃ"
},
"nplurals=2; plural=(n != 1);");
