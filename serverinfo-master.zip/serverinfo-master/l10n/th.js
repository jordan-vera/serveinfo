OC.L10N.register(
    "serverinfo",
    {
    "Users" : "ผู้ใช้งาน",
    "Groups" : "กลุ่ม",
    "Copy" : "คัดลอก",
    "Copied!" : "คัดลอกแล้ว",
    "Not supported!" : "ไม่สนับสนุน",
    "Press ⌘-C to copy." : "กด ⌘-C เพื่อคัดลอก",
    "Press Ctrl-C to copy." : "กด Ctrl-C เพื่อคัดลอก",
    "System" : "ระบบ",
    "Size" : "ขนาด",
    "Hostname" : "ชื่อโฮสต์",
    "Shares" : "แชร์",
    "Type:" : "ชนิด:",
    "Size:" : "ขนาด:"
},
"nplurals=1; plural=0;");
