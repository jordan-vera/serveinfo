OC.L10N.register(
    "serverinfo",
    {
    "Users" : "Utilizatori",
    "Groups" : "Grupuri",
    "24 hours" : "24 ore",
    "1 hour" : "1 oră",
    "Copy" : "Copiază",
    "Copied!" : "S-a copiat!",
    "Not supported!" : "Nu este suportat!",
    "Press ⌘-C to copy." : "Apasă ⌘-C pentru copiere.",
    "Press Ctrl-C to copy." : "Apasă Ctrl-C pentru copiere.",
    "System" : "Sistem",
    "Size" : "Mărime",
    "Hostname" : "Nume mașină",
    "Status" : "Stare",
    "Shares" : "Partajări",
    "Type:" : "Tip:",
    "Size:" : "Mărime:",
    "Nextcloud" : "Nextcloud"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
