OC.L10N.register(
    "serverinfo",
    {
    "Users" : "អ្នកប្រើ",
    "Groups" : "ក្រុ",
    "Size" : "ទំហំ",
    "Shares" : "ចែក​រំលែក",
    "Type:" : "ប្រភេទ៖",
    "Size:" : "ទំហំ៖"
},
"nplurals=1; plural=0;");
