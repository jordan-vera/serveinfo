OC.L10N.register(
    "serverinfo",
    {
    "Copied!" : "Yenɣel!",
    "Not supported!" : "Ur yettusefrak ara!",
    "Press ⌘-C to copy." : "Senned ɣef ⌘-C akken ad tneɣleḍ.",
    "Press Ctrl-C to copy." : "Senned ɣef Ctrl-C akken ad tneɣleḍ."
},
"nplurals=2; plural=(n != 1);");
