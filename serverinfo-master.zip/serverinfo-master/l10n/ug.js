OC.L10N.register(
    "serverinfo",
    {
    "Users" : "ئىشلەتكۈچىلەر",
    "Groups" : "گۇرۇپپا",
    "Size" : "چوڭلۇقى",
    "Type:" : "تىپى:",
    "Size:" : "چوڭلۇقى:"
},
"nplurals=1; plural=0;");
