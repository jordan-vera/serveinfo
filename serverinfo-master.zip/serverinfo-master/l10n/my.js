OC.L10N.register(
    "serverinfo",
    {
    "Copied!" : "ကူးယူပြီး!",
    "Not supported!" : "အထောက်အပံ့ မပြု!",
    "Press ⌘-C to copy." : "ကူးယူရန်အတွက် ⌘-C ကိုနှိပ်ပါ။",
    "Press Ctrl-C to copy." : "ကူးယူရန်အတွက် Ctrl-C ကိုနှိပ်ပါ။"
},
"nplurals=1; plural=0;");
