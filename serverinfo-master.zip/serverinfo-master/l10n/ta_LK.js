OC.L10N.register(
    "serverinfo",
    {
    "Users" : "பயனாளர்",
    "Groups" : "குழுக்கள்",
    "Size" : "அளவு",
    "Type:" : "வகை:",
    "Size:" : "அளவு:"
},
"nplurals=2; plural=(n != 1);");
