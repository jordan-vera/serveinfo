OC.L10N.register(
    "serverinfo",
    {
    "Groups" : "Խմբեր",
    "Copy" : "պատճենահանել",
    "Size" : "Չափս",
    "Type:" : "Տիպ.",
    "Size:" : "Չափս."
},
"nplurals=2; plural=(n != 1);");
