OC.L10N.register(
    "serverinfo",
    {
    "Groups" : "Bólkar",
    "Copy" : "Kopi",
    "Copied!" : "Kopiera!",
    "Press ⌘-C to copy." : "Trýst ⌘-C fyri at kopiera.",
    "Press Ctrl-C to copy." : "Trýst Ctrl-C fyri at kopiera."
},
"nplurals=2; plural=(n != 1);");
