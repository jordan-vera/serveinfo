OC.L10N.register(
    "serverinfo",
    {
    "Users" : "用戶",
    "Groups" : "群組",
    "Copied!" : "已複製!",
    "Not supported!" : "不支援!",
    "Press ⌘-C to copy." : "按下 ⌘-C 複製",
    "Press Ctrl-C to copy." : "按下 Ctrl-C 複製",
    "Size" : "大小",
    "Shares" : "分享",
    "Type:" : "類別：",
    "Size:" : "大小："
},
"nplurals=1; plural=0;");
